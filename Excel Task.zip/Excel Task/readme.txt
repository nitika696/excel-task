Url: http://localhost/assign

Database Name: assign

-----------------------------

Tables
tbl_ques => Saved Excel sheet data
tbl_log => Saved Excel sheet data with logic

-------------------------------
